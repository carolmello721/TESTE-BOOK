DO $$
DECLARE
    v_author_id UUID;
    v_reader_id UUID;
    v_book_id UUID;
    v_tag_dark_id UUID;
    v_tag_enemies_id UUID;
    v_chapter_id UUID;
BEGIN
    INSERT INTO users (username, email, password_hash, is_reader, is_author, premium_subscription, prefer_dark_mode)
    VALUES ('gabriella_author', 'gabi@leitura.io', 'hash_12345', true, true, true, true)
    RETURNING id INTO v_author_id;

    INSERT INTO users (username, email, password_hash, is_reader, is_author, premium_subscription)
    VALUES ('leitor_compulsivo', 'joao@leitura.io', 'hash_00000', true, false, true)
    RETURNING id INTO v_reader_id;

    INSERT INTO tags (name, description)
    VALUES ('Dark Romance', 'Envolve atmosferas sombrias e temas intensos e moralmente cinzas.')
    RETURNING id INTO v_tag_dark_id;

    INSERT INTO tags (name, description)
    VALUES ('Enemies to Lovers', 'Personagens começam em conflito e desenvolvem paixão e amor mútuo.')
    RETURNING id INTO v_tag_enemies_id;

    INSERT INTO books (author_id, title, synopsis, cover_url, status, tension_thermometer, main_characters)
    VALUES (
        v_author_id,
        'Código de Tensão',
        'Katarina e Matteo são peças centrais num tabuleiro mortal onde o amor é a cartada final...',
        's3://plat-livros-bucket/covers/codigo-de-tensao.webp',
        'PUBLISHED',
        10,
        ARRAY['Katarina', 'Matteo']
    )
    RETURNING id INTO v_book_id;

    INSERT INTO book_tags (book_id, tag_id) VALUES (v_book_id, v_tag_dark_id);
    INSERT INTO book_tags (book_id, tag_id) VALUES (v_book_id, v_tag_enemies_id);

    INSERT INTO chapters (book_id, title, content, word_count, status, chapter_order, published_at)
    VALUES (
        v_book_id,
        'Capítulo 1: O Inimigo Desconhecido',
        'Katarina apertou o passo sob a chuva torrencial. Ela sabia que Matteo a estava seguindo...',
        3200,
        'PUBLISHED',
        1,
        NOW()
    )
    RETURNING id INTO v_chapter_id;

    INSERT INTO reading_progress (user_id, book_id, current_chapter_id, page_percentage)
    VALUES (
        v_reader_id,
        v_book_id,
        v_chapter_id,
        65.50
    );

    RAISE NOTICE 'Seed de teste injetado com sucesso!';
END $$;
