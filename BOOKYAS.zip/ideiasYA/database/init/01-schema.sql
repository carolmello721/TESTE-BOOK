CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";

CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    is_reader BOOLEAN DEFAULT true,
    is_author BOOLEAN DEFAULT false,
    premium_subscription BOOLEAN DEFAULT false,
    prefer_dark_mode BOOLEAN DEFAULT true,
    gamification_points INT DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX idx_users_gamification ON users(gamification_points DESC);

CREATE TYPE book_status AS ENUM ('DRAFT', 'PUBLISHED', 'ARCHIVED');
CREATE TABLE books (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    author_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    title VARCHAR(255) NOT NULL,
    synopsis TEXT,
    cover_url VARCHAR(512),
    status book_status DEFAULT 'DRAFT',
    tension_thermometer SMALLINT NOT NULL CHECK (tension_thermometer BETWEEN 1 AND 10),
    main_characters VARCHAR(100)[],
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX idx_books_author_id ON books(author_id);
CREATE INDEX idx_books_status_tension ON books(status, tension_thermometer DESC);
CREATE INDEX idx_books_title_trgm ON books USING gin (title gin_trgm_ops);

CREATE TYPE chapter_status AS ENUM ('DRAFT', 'BETA', 'PUBLISHED');
CREATE TABLE chapters (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    book_id UUID NOT NULL REFERENCES books(id) ON DELETE CASCADE,
    title VARCHAR(255) NOT NULL,
    content TEXT,
    word_count INT DEFAULT 0,
    status chapter_status DEFAULT 'DRAFT',
    chapter_order INT NOT NULL,
    scheduled_at TIMESTAMPTZ,
    published_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE (book_id, chapter_order)
);
CREATE INDEX idx_chapters_book_status ON chapters(book_id, status);
CREATE INDEX idx_chapters_scheduled ON chapters(scheduled_at) WHERE status = 'DRAFT';

CREATE TABLE tags (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(100) UNIQUE NOT NULL,
    description TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX idx_tags_name_trgm ON tags USING gin (name gin_trgm_ops);

CREATE TABLE book_tags (
    book_id UUID NOT NULL REFERENCES books(id) ON DELETE CASCADE,
    tag_id UUID NOT NULL REFERENCES tags(id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    PRIMARY KEY (book_id, tag_id)
);
CREATE INDEX idx_book_tags_tag_id ON book_tags(tag_id);

CREATE TABLE reading_progress (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    book_id UUID NOT NULL REFERENCES books(id) ON DELETE CASCADE,
    current_chapter_id UUID NOT NULL REFERENCES chapters(id) ON DELETE CASCADE,
    page_percentage DECIMAL(5,2) DEFAULT 0.00 CHECK (page_percentage >= 0 AND page_percentage <= 100),
    last_read_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE (user_id, book_id)
);
CREATE INDEX idx_progress_author_analytics ON reading_progress(current_chapter_id);
CREATE INDEX idx_progress_user_last_read ON reading_progress(user_id, last_read_at DESC);
