# 🔐 Fase 3 - Segurança, Auth JWT e Carteira Virtual

Executamos um *refactoring* limpo e robusto na raiz do seu projeto. A Gamificação de pontuações foi eliminada em prol de uma modelagem de economia real `coin_balance`, e o sistema agora está devidamente barricado com Tokenização!

## 🗂️ O Que Entregamos Em Backend
- **Prisma Schema (`schema.prisma`)**: Trocamos booleanos confusos pelo `enum Role` focado (READER, AUTHOR, ADMIN). Adicionamos o `coin_balance` como Inteiro na tabela de Usuários.
- **Fastify/JWT (`src/plugins/auth.ts`)**: Implementamos um Middleware `authenticate` capaz de interceptar e decodificar Cabeçalhos HTTP de rotas de segurança.
- **Camada Auth (`/auth`)**:
  - `registerSchema / loginSchema`: Zods com validação profunda para os dados de entrada.
  - `UserRepository`: Abstraindo as criações assíncronas do banco usando *Casting*.
  - `AuthService`: Faz a criptografia (BcryptJS **genSalt(10)**) salvando senhas indescritíveis.
- **A Rota de Progresso Isolada**: O seu `POST /reading/progress` agora exige obrigatoriamente passagem por `{ onRequest: [authenticate] }`.

---

## 🏃 Passo-a-passo: Sincronize e Teste

### 1) Sincronizar o Banco (Migration Prisma)
Como modifiquei o `schema.prisma`, os modelos alterados agora precisam ser injetados no PostgreSQL limpo que está rodando no seu Docker. No terminal do VS Code, dento da pasta **backend**, rode a migration:
```powershell
npx prisma migrate dev --name "init_auth_and_economy"
```
> [!NOTE]
> Essa migration descartará os dados do Seed anterior por incompatibilidade (removemos colunas que o seed utilizou), portanto estamos rodando limpos, prontos e seguros para a real utilização da aplicação!

Após isso, o banco está atualizado. Reinstale dependências caso não tenha feito (ele baixará nossos pacotes JWT) e atualize os tipos:
```powershell
npm install
npx prisma generate
```

### 2) Ligue a API
```powershell
npm run dev
```

### 3) Testando a Rota de Criação de Conta
Use seu Postman/Insomnia, Extensão ThunderClient, ou o próprio Curl no terminal:
**Método:** `POST`
**URL:** `http://localhost:3333/auth/register`
**Body JSON:**
```json
{
  "username": "gabriella_author",
  "email": "gabi@leitura.io",
  "password": "super_senha_123",
  "role": "AUTHOR"
}
```
**Resultado Esperado**: Retornará status HTTP `201` contendo seu ID de banco, *role*, e `coin_balance: 0`. Tente logar no `/auth/login` passando e-mail e senha para receber o **Token JWT** em mãos! 🚀
