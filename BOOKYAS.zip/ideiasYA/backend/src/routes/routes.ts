import { FastifyInstance } from 'fastify';
import { BooksController } from '../controllers/books.controller';
import { ProgressController } from '../controllers/progress.controller';
import { AuthController } from '../controllers/auth.controller';
import { authenticate } from '../plugins/auth';

export async function appRoutes(app: FastifyInstance) {
  // Rotas Públicas
  app.post('/auth/register', AuthController.register);
  app.post('/auth/login', AuthController.login);
  app.get('/books/trending', BooksController.getTrending);
  app.get('/books/:id/tropes', BooksController.getTropes);

  // Rotas Privadas (Protegidas por JWT)
  app.post(
    '/reading/progress',
    { onRequest: [authenticate] },
    ProgressController.postProgress
  );
}
