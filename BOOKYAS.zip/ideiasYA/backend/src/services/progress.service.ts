import { ProgressRepository } from '../repositories/progress.repository';
import { ReadingProgressDto } from '../schemas/progress.schema';

export class ProgressService {
  static async updateReadingProgress(data: ReadingProgressDto) {
    try {
      const result = await ProgressRepository.upsertProgress(data);
      return result;
    } catch (error) {
      console.error("Falha ao registrar progresso:", error);
      throw new Error("Unable to update progress DB. Check referenced IDs.");
    }
  }
}
