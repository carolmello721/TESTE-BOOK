import bcrypt from 'bcryptjs';
import { UserRepository } from '../repositories/user.repository';
import { LoginDto, RegisterDto } from '../schemas/auth.schema';

export class AuthService {
  static async register(data: RegisterDto) {
    const existingUser = await UserRepository.findByEmail(data.email);
    if (existingUser) {
      throw new Error('Email_In_Use');
    }
    
    // Hash robusto usando 10 rounds de salt
    const salt = await bcrypt.genSalt(10);
    const passwordHash = await bcrypt.hash(data.password, salt);
    
    const newUser = await UserRepository.create(data, passwordHash);
    
    // Suprimindo dados sensíveis no retorno
    const { password_hash, ...userProfile } = newUser;
    return userProfile;
  }

  static async login(data: LoginDto) {
    const user = await UserRepository.findByEmail(data.email);
    if (!user) {
      throw new Error('Invalid_Credentials');
    }
    
    const isValid = await bcrypt.compare(data.password, user.password_hash);
    if (!isValid) {
      throw new Error('Invalid_Credentials');
    }
    
    return {
      id: user.id,
      email: user.email,
      role: user.role,
      name: user.username,
    };
  }
}
