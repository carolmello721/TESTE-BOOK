import { BooksRepository } from '../repositories/books.repository';

export class BooksService {
  static async getTrending() {
    const books = await BooksRepository.getTrendingBooks();
    return books;
  }

  static async getBookTropes(bookId: string) {
    const book = await BooksRepository.getBookWithTropes(bookId);
    if (!book) {
      throw new Error('Book not found');
    }
    
    // Formatar retorno para enviar as tags limpas e organizadas no mesmo endpoint
    const tags = book.book_tags.map(bt => bt.tag);
    
    return {
      book: {
        id: book.id,
        title: book.title,
        synopsis: book.synopsis,
        tension_thermometer: book.tension_thermometer,
        author: book.author.username
      },
      tropes: tags
    };
  }
}
