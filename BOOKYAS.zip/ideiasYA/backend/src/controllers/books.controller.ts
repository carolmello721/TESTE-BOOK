import { FastifyRequest, FastifyReply } from 'fastify';
import { BooksService } from '../services/books.service';

export class BooksController {
  static async getTrending(request: FastifyRequest, reply: FastifyReply) {
    try {
      const books = await BooksService.getTrending();
      return reply.status(200).send(books);
    } catch (error) {
      return reply.status(500).send({ error: 'Internal Server Error' });
    }
  }

  static async getTropes(request: FastifyRequest<{ Params: { id: string } }>, reply: FastifyReply) {
    try {
      const { id } = request.params;
      const data = await BooksService.getBookTropes(id);
      return reply.status(200).send(data);
    } catch (error: any) {
      if (error.message === 'Book not found') {
        return reply.status(404).send({ error: 'Book not found' });
      }
      return reply.status(500).send({ error: 'Internal Server Error' });
    }
  }
}
