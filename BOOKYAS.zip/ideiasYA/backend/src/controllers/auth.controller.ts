import { FastifyRequest, FastifyReply } from 'fastify';
import { registerSchema, loginSchema } from '../schemas/auth.schema';
import { AuthService } from '../services/auth.service';
import { z } from 'zod';

export class AuthController {
  static async register(request: FastifyRequest, reply: FastifyReply) {
    try {
      const data = registerSchema.parse(request.body);
      const user = await AuthService.register(data);
      return reply.status(201).send(user);
    } catch (error: any) {
      if (error instanceof z.ZodError) {
        return reply.status(400).send({ message: 'Validation error', issues: error.issues });
      }
      if (error.message === 'Email_In_Use') {
        return reply.status(409).send({ error: 'Email já cadastrado.' });
      }
      return reply.status(500).send({ error: 'Internal Server Error' });
    }
  }

  static async login(request: FastifyRequest, reply: FastifyReply) {
    try {
      const data = loginSchema.parse(request.body);
      
      const payload = await AuthService.login(data);
      
      // Assinatura JWT pelo plugin core do Fastify (segurança elevada)
      const token = request.server.jwt.sign(payload);
      
      return reply.status(200).send({ token, user: payload });
    } catch (error: any) {
      if (error instanceof z.ZodError) {
        return reply.status(400).send({ message: 'Validation error', issues: error.issues });
      }
      if (error.message === 'Invalid_Credentials') {
        return reply.status(401).send({ error: 'Credenciais Inválidas.' });
      }
      return reply.status(500).send({ error: 'Internal Server Error' });
    }
  }
}
