import { FastifyRequest, FastifyReply } from 'fastify';
import { readingProgressSchema } from '../schemas/progress.schema';
import { ProgressService } from '../services/progress.service';
import { z } from 'zod';

export class ProgressController {
  static async postProgress(request: FastifyRequest, reply: FastifyReply) {
    try {
      // O Zod é a Source of Truth absoluta que barrará a requisição antes que chegue a camada de banco de dados
      const data = readingProgressSchema.parse(request.body);
      
      const result = await ProgressService.updateReadingProgress(data);
      return reply.status(201).send(result);
      
    } catch (error) {
      if (error instanceof z.ZodError) {
        // Envio ágil e estruturado dos erros de validação da schema
        return reply.status(400).send({
          message: 'Payload de requisição inválido! Faltando UUIDs ou porcentagem incorreta.',
          issues: error.issues,
        });
      }
      return reply.status(500).send({ error: 'Internal Server Error' });
    }
  }
}
