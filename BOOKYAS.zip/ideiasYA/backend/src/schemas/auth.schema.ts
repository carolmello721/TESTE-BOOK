import { z } from 'zod';

export const registerSchema = z.object({
  username: z.string().min(3, { message: "O username deve ter pelo menos 3 caracteres." }),
  email: z.string().email({ message: "Insira um email válido." }),
  password: z.string().min(6, { message: "A senha deve ter no mínimo 6 caracteres." }),
  role: z.enum(['READER', 'AUTHOR', 'ADMIN']).optional().default('READER'),
});

export const loginSchema = z.object({
  email: z.string().email(),
  password: z.string()
});

export type RegisterDto = z.infer<typeof registerSchema>;
export type LoginDto = z.infer<typeof loginSchema>;
