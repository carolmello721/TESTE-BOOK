import { z } from 'zod';

export const readingProgressSchema = z.object({
  userId: z.string().uuid({ message: "userId deve ser um UUID válido." }),
  bookId: z.string().uuid({ message: "bookId deve ser um UUID válido." }),
  chapterId: z.string().uuid({ message: "chapterId deve ser um UUID válido." }),
  pagePercentage: z
    .number()
    .min(0, { message: "A porcentagem não pode ser menor que 0." })
    .max(100, { message: "A porcentagem máxima permitida é 100." }),
});

export type ReadingProgressDto = z.infer<typeof readingProgressSchema>;
