import Fastify from 'fastify';
import cors from '@fastify/cors';
import fastifyJwt from '@fastify/jwt';
import { appRoutes } from './routes/routes';
import { authenticate } from './plugins/auth';

const app = Fastify({ logger: true });

app.register(cors, {
  origin: '*',
});

app.register(fastifyJwt, {
  secret: 'supersecret_key_ideiasya_123'
});

app.decorate('authenticate', authenticate);

app.register(appRoutes);

const start = async () => {
  try {
    await app.listen({ port: 3333, host: '0.0.0.0' });
    console.log('🚀 API Fastify (Auth + Moedas Habilitadas) rodando na porta 3333');
  } catch (err) {
    app.log.error(err);
    process.exit(1);
  }
};

start();
