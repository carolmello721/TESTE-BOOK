import { prisma } from '../lib/prisma';

export class BooksRepository {
  static async getTrendingBooks() {
    return await prisma.book.findMany({
      orderBy: { tension_thermometer: 'desc' },
      take: 10,
      include: { author: { select: { username: true } } },
    });
  }

  static async getBookWithTropes(bookId: string) {
    return await prisma.book.findUnique({
      where: { id: bookId },
      include: {
        book_tags: {
          include: { tag: true },
        },
        author: { select: { username: true } },
      },
    });
  }
}
