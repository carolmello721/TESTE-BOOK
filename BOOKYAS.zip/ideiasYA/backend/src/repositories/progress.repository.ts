import { prisma } from '../lib/prisma';
import { ReadingProgressDto } from '../schemas/progress.schema';

export class ProgressRepository {
  static async upsertProgress(data: ReadingProgressDto) {
    return await prisma.readingProgress.upsert({
      where: {
        user_id_book_id: {
          user_id: data.userId,
          book_id: data.bookId,
        },
      },
      update: {
        current_chapter_id: data.chapterId,
        page_percentage: data.pagePercentage,
        last_read_at: new Date(),
      },
      create: {
        user_id: data.userId,
        book_id: data.bookId,
        current_chapter_id: data.chapterId,
        page_percentage: data.pagePercentage,
      },
    });
  }
}
