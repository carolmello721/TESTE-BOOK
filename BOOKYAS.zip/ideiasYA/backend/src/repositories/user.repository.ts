import { prisma } from '../lib/prisma';
import { RegisterDto } from '../schemas/auth.schema';

export class UserRepository {
  static async findByEmail(email: string) {
    return await prisma.user.findUnique({ where: { email } });
  }

  static async findByUsername(username: string) {
    return await prisma.user.findUnique({ where: { username } });
  }

  static async create(data: RegisterDto, passwordHash: string) {
    return await prisma.user.create({
      data: {
        username: data.username,
        email: data.email,
        password_hash: passwordHash,
        role: data.role as any, // casting por tipagem do Prisma
        coin_balance: 0,
      },
    });
  }
}
