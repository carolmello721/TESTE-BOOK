"use client";
import { UserCircle, Coins } from "lucide-react";
import { useCoinStore } from "@/context/CoinStoreContext";
import Link from "next/link";

export default function Navbar() {
  // Chamada Global do Contexto Native React
  const { openStore } = useCoinStore();

  return (
    <nav className="sticky top-0 z-50 w-full bg-ideiasBg/80 backdrop-blur-xl border-b border-white/5">
      <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
        {/* LOGO */}
        <Link href="/" className="text-xl font-black tracking-tighter text-white">
          Ideias<span className="text-ideiasAccent drop-shadow-md">YA</span>
        </Link>

        {/* PROFILE & COINS TRIGGER */}
        <div className="flex items-center space-x-4">
          <button 
            onClick={openStore}
            className="flex items-center space-x-2 bg-[#111] hover:bg-[#1a1a1a] px-3 py-1.5 rounded-full border border-ideiasAccent/30 hover:border-ideiasAccent transition-all shadow-[0_0_10px_rgba(159,18,57,0.1)] hover:shadow-[0_0_15px_rgba(159,18,57,0.3)] active:scale-95 group"
          >
            <Coins size={16} className="text-ideiasAccent group-hover:scale-110 transition-transform" />
            <span className="text-sm font-bold text-white tracking-tighter">150</span>
            <span className="text-[10px] text-zinc-500 uppercase font-black ml-1 hidden sm:block group-hover:text-zinc-300">Sumar</span>
          </button>
          
          <Link href="/studio" className="text-zinc-500 hover:text-white transition-all active:scale-95">
             <UserCircle size={28} />
          </Link>
        </div>
      </div>
    </nav>
  );
}
