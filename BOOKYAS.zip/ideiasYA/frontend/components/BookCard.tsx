interface BookCardProps {
  title: string;
  author: string;
  coverUrl: string;
  tensionLevel: number; // 1 to 10
  tropes: string[];
}

export default function BookCard({
  title,
  author,
  coverUrl,
  tensionLevel,
  tropes,
}: BookCardProps) {
  // Calculus for thermometer width
  const tensionPercentage = (tensionLevel / 10) * 100;

  return (
    <div className="group relative flex-none w-64 md:w-72 bg-ideiasSurface rounded-xl overflow-hidden hover:ring-2 ring-ideiasAccent transition-all snap-start shadow-xl shadow-black/40">
      
      {/* Cover Image Area with Overlay */}
      <div className="w-full h-96 relative bg-gradient-to-b from-ideiasSurface to-ideiasBg overflow-hidden flex items-center justify-center">
        {coverUrl ? (
          <img
            src={coverUrl}
            alt={title}
            className="w-full h-full object-cover z-10 relative saturate-[0.85] group-hover:saturate-100 transition-all duration-300 group-hover:scale-105"
          />
        ) : (
            <span className="opacity-30 text-ideiasMuted text-xs z-0 absolute">Sem Capa</span>
        )}
        
        {/* Gradient Overlay for Text Visibility */}
        <div className="absolute inset-0 bg-gradient-to-t from-ideiasBg via-ideiasSurface/40 to-transparent z-10 pointer-events-none" />
      </div>

      {/* Content Positioned Over Image */}
      <div className="p-4 absolute bottom-0 w-full z-20">
        <h3 className="text-lg font-bold text-ideiasText leading-tight mb-1 truncate drop-shadow-md">
          {title}
        </h3>
        <p className="text-sm text-ideiasMuted mb-3 truncate drop-shadow-md">{author}</p>

        {/* Tension Thermometer */}
        <div className="mb-3">
          <div className="flex justify-between items-center mb-1">
            <span className="text-[10px] uppercase font-bold tracking-widest text-ideiasText drop-shadow-md">Tensão</span>
            <span className="text-[10px] text-ideiasAccent font-bold">{tensionLevel}/10</span>
          </div>
          <div className="w-full bg-black/80 rounded-full h-1.5 overflow-hidden">
            <div 
              className="bg-ideiasAccent h-1.5 rounded-full shadow-[0_0_8px_rgba(159,18,57,0.8)]" 
              style={{ width: `${tensionPercentage}%` }}
            />
          </div>
        </div>

        {/* Tropes Chips */}
        <div className="flex flex-wrap gap-2 mt-2 max-h-12 overflow-hidden">
          {tropes.map((trope, idx) => (
            <span
              key={idx}
              className="text-[10px] px-2 py-0.5 rounded-full bg-ideiasBg/80 border border-ideiasMuted/20 text-ideiasMuted whitespace-nowrap backdrop-blur-sm"
            >
              {trope}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}
