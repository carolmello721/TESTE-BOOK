"use client";

import { useState } from "react";
import { X, QrCode, Copy, Coins, CheckCircle2 } from "lucide-react";

type StoreStep = "PACKAGES" | "CHECKOUT";

export default function CoinStoreModal({ onClose }: { onClose: () => void }) {
  const [step, setStep] = useState<StoreStep>("PACKAGES");
  const [selectedPackage, setSelectedPackage] = useState<number | null>(null);
  const [copied, setCopied] = useState(false);

  // Mocks do catálogo monetário
  const packages = [
    { id: 1, moedas: 100, price: "R$ 5,90", tag: "" },
    { id: 2, moedas: 500, price: "R$ 24,90", tag: "MAIS POPULAR" },
    { id: 3, moedas: 1200, price: "R$ 49,90", tag: "MELHOR VALOR" },
  ];

  const handleSelect = (pkgId: number) => {
    setSelectedPackage(pkgId);
    setStep("CHECKOUT"); // Dispara transição suave para as chaves do PIX
  };

  const copyPix = () => {
    navigator.clipboard.writeText("00020101021126580014br.gov.bcb.pix...");
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-[9999] flex items-center justify-center p-4 backdrop-blur-md bg-black/70 animate-in fade-in duration-200">
      
      {/* Absolute invisível para fechar a store ao clicar no abismo for fora do componente */}
      <div className="absolute inset-0 cursor-pointer" onClick={onClose} />

      {/* Modal Box / Card Flutuante */}
      <div className="relative w-full max-w-md bg-[#0a0a0a] border border-white/10 rounded-3xl shadow-[0_0_80px_rgba(0,0,0,0.9)] overflow-hidden animate-in zoom-in-95 duration-200 select-none">
        
        {/* Header Elegante */}
        <div className="flex items-center justify-between p-5 border-b border-white/5 bg-white/5">
          <h2 className="text-xl font-black text-white flex items-center font-sans tracking-tighter">
            <Coins size={22} className="text-ideiasAccent mr-2" />
            Loja do Leitor
          </h2>
          <button onClick={onClose} className="text-zinc-500 hover:text-white transition-colors bg-white/5 rounded-full p-2 align-middle hover:bg-white/10 active:scale-95">
            <X size={20} />
          </button>
        </div>

        {/* Content Area / Engine Transitória de Páginas */}
        <div className="p-6">
          {step === "PACKAGES" && (
            <div className="space-y-4 animate-in slide-in-from-left-4 fade-in duration-300">
              <p className="text-sm text-zinc-400 mb-6 font-sans leading-relaxed">
                Adquira moedas virtuais instantaneamente para desbloquear atmosferas tensas e apoiar escritores que não temem amarras.
              </p>
              
              <div className="space-y-4 max-h-[60vh] overflow-y-auto hide-scrollbar">
                {packages.map((pkg) => (
                 <div 
                   key={pkg.id} 
                   onClick={() => handleSelect(pkg.id)}
                   className={`relative p-5 rounded-2xl border cursor-pointer transition-all hover:scale-[1.02] active:scale-[0.98] ${
                     pkg.tag === "MAIS POPULAR" 
                     ? "border-ideiasAccent bg-gradient-to-r from-ideiasAccent/10 to-[#0a0a0a] shadow-[0_0_20px_rgba(159,18,57,0.15)] hover:bg-ideiasAccent/20 relative overflow-hidden" 
                     : "border-white/10 bg-[#111] hover:bg-white/5"
                   }`}
                 >
                   {pkg.tag && (
                      <div className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-ideiasAccent text-white text-[10px] font-black px-4 py-0.5 rounded-full tracking-widest shadow-lg whitespace-nowrap z-10">
                        {pkg.tag}
                      </div>
                   )}
                   
                   {/* Light reflection mock for best seller */}
                   {pkg.tag === "MAIS POPULAR" && <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent w-full h-full -skew-x-12 opacity-50" />}

                   <div className="flex justify-between items-center relative z-10">
                     <div className="flex items-center space-x-3">
                       <div className={`p-2.5 rounded-full ${pkg.tag === "MAIS POPULAR" ? 'bg-ideiasAccent/20' : 'bg-white/5'}`}>
                          <Coins size={28} className={pkg.tag === "MAIS POPULAR" ? "text-ideiasAccent" : "text-zinc-500"} />
                       </div>
                       <span className="text-4xl font-black text-white tracking-tighter">{pkg.moedas}</span>
                     </div>
                     <div className="text-lg font-bold text-white bg-black/60 border border-white/5 px-4 py-1.5 rounded-lg shadow-inner">
                       {pkg.price}
                     </div>
                   </div>
                 </div>
                ))}
              </div>
            </div>
          )}

          {/* O Fim Lógico do Checkout / Nubank Premium Style */}
          {step === "CHECKOUT" && (
            <div className="flex flex-col items-center animate-in slide-in-from-right-4 fade-in duration-300 text-center">
               <h3 className="text-xl font-bold text-white mb-2">Escaneie o QR Code</h3>
               <p className="text-sm text-zinc-500 mb-8 max-w-[250px]">O Pix é computado na hora. Suas moedas são atreladas ao seu UUID ao cair na malha.</p>
               
               <div className="bg-white p-6 rounded-3xl mb-8 shadow-[0_0_30px_rgba(255,255,255,0.2)] ring-8 ring-white/5">
                 <QrCode size={180} className="text-[#0a0a0a]" strokeWidth={1} />
               </div>

               <button 
                 onClick={copyPix}
                 className={`w-full py-4 px-4 rounded-2xl font-bold flex items-center justify-center space-x-2 transition-all shadow-lg text-sm sm:text-base ${
                   copied 
                   ? "bg-emerald-500 text-black shadow-[0_0_20px_rgba(16,185,129,0.4)]"
                   : "bg-[#222] text-white hover:bg-[#333] shadow-black/40 hover:border hover:border-white/10"
                 }`}
               >
                 {copied ? (
                   <>
                     <CheckCircle2 size={20} />
                     <span>Código Copiado!</span>
                   </>
                 ) : (
                   <>
                     <Copy size={20} />
                     <span>Copiar Chave PIX (Copia e Cola)</span>
                   </>
                 )}
               </button>

               <button 
                 onClick={() => setStep("PACKAGES")}
                 className="mt-6 text-sm text-zinc-600 hover:text-white transition-colors underline underline-offset-4"
               >
                 Ainda quer analisar combos? Volte os passos
               </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
