"use client";
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { BookOpen, LayoutDashboard, Coins, ArrowLeft } from 'lucide-react';

export default function Sidebar() {
  const pathname = usePathname();

  const links = [
    { href: '/studio', label: 'Dashboard', icon: LayoutDashboard },
    { href: '/studio/book/new', label: 'Criar Capítulo', icon: BookOpen },
    { href: '#', label: 'Receita Virtual', icon: Coins },
  ];

  return (
    <aside className="fixed left-0 top-0 h-screen w-16 md:w-64 bg-ideiasSurface border-r border-[#2a2a2a] flex flex-col justify-between py-6 transition-all z-40">
      <div>
        <div className="px-4 md:px-8 mb-10 hidden md:block">
          <Link href="/" className="text-xl font-bold tracking-tighter text-ideiasText">
            Estúdio<span className="text-ideiasAccent">YA</span>
          </Link>
        </div>
        
        <nav className="flex flex-col space-y-2 px-2 md:px-4">
          {links.map((link) => {
            const isActive = pathname === link.href;
            const Icon = link.icon;
            return (
              <Link
                key={link.href}
                href={link.href}
                className={`flex items-center space-x-3 px-3 py-3 rounded-lg transition-colors group ${
                  isActive 
                  ? 'bg-ideiasAccent text-white border border-ideiasAccent/40 shadow-inner' 
                  : 'text-ideiasMuted hover:bg-white/5 hover:text-white'
                }`}
              >
                <Icon size={20} className={isActive ? "opacity-100 drop-shadow-[0_0_8px_rgba(255,255,255,0.5)]" : "opacity-70 group-hover:opacity-100"} />
                <span className="hidden md:inline font-medium text-sm">{link.label}</span>
              </Link>
            )
          })}
        </nav>
      </div>

      <div className="px-2 md:px-4">
        <Link
          href="/"
          className="flex items-center space-x-3 px-3 py-3 rounded-lg text-ideiasMuted hover:bg-zinc-800 hover:text-white transition-colors border border-transparent hover:border-white/10"
        >
          <ArrowLeft size={20} />
          <span className="hidden md:inline font-medium text-sm">Sair do Estúdio</span>
        </Link>
      </div>
    </aside>
  );
}
