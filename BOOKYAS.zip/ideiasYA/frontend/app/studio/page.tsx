import { BookText, Target, Eye, TrendingUp } from "lucide-react";
import Link from "next/link";

export default function StudioDashboard() {
  return (
    <div className="p-8 md:p-12">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-10 gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tighter text-white mb-2">Visão Geral</h1>
          <p className="text-zinc-500 text-sm">Bem-vindo(a) de volta. Seus thrillers estão retendo mentes.</p>
        </div>
        <Link href="/studio/book/new" className="px-5 py-2.5 bg-ideiasText text-ideiasBg hover:bg-zinc-300 transition-colors font-bold rounded-lg text-sm flex items-center shadow-lg hover:scale-105 active:scale-95 duration-200">
          <BookText size={16} className="mr-2" />
          Novo Livro / Capítulo
        </Link>
      </div>

      {/* Grid de Metricas */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
        <div className="bg-ideiasSurface p-6 rounded-2xl border border-white/5 shadow-2xl relative overflow-hidden group hover:border-white/10 transition-colors">
          <div className="absolute top-0 right-0 p-4 opacity-[0.03] group-hover:opacity-10 group-hover:scale-110 transition-all duration-500 text-white">
            <Eye size={120} />
          </div>
          <p className="text-zinc-400 font-bold text-[11px] tracking-widest mb-2 font-sans">LEITURAS DO MÊS</p>
          <h3 className="text-5xl font-extrabold text-white tracking-tighter">12.4K</h3>
          <p className="text-emerald-500 text-xs mt-4 flex items-center font-medium"><TrendingUp size={14} className="mr-1.5" /> +15% desde o último mês</p>
        </div>

        <div className="bg-ideiasSurface p-6 rounded-2xl border border-white/5 shadow-2xl relative overflow-hidden group hover:border-white/10 transition-colors">
          <div className="absolute top-0 right-0 p-4 opacity-[0.03] group-hover:opacity-10 group-hover:scale-110 transition-all duration-500 text-white">
             <Target size={120} />
          </div>
          <p className="text-zinc-400 font-bold text-[11px] tracking-widest mb-2 font-sans">CONVERSÃO DO CADEADO</p>
          <h3 className="text-5xl font-extrabold text-white tracking-tighter">42%</h3>
          <p className="text-emerald-500 text-xs mt-4 flex items-center font-medium"><TrendingUp size={14} className="mr-1.5" /> Extrema retenção detectada</p>
        </div>

        <div className="bg-gradient-to-br from-ideiasAccent to-[#2e0410] p-6 rounded-2xl border border-ideiasAccent/50 shadow-[0_0_30px_rgba(159,18,57,0.15)] relative overflow-hidden">
          <div className="absolute inset-0 bg-ideiasAccent/20 blur-3xl rounded-full scale-150 transform -translate-y-10" />
          <p className="text-white/60 font-bold text-[11px] tracking-widest mb-2 font-sans relative z-10">RECEITA VIRTUAL (ACUMULADO)</p>
          <h3 className="text-5xl font-extrabold text-white relative z-10 tracking-tighter">4.850 <span className="text-xl font-medium opacity-70 tracking-normal ml-1">Moedas</span></h3>
          <p className="text-white/60 text-xs mt-4 relative z-10 font-medium">Equivalente de saque no próximo ciclo</p>
        </div>
      </div>
    </div>
  );
}
