"use client";

import { useState } from "react";
import { UploadCloud, CheckCircle, Coins, ChevronLeft } from "lucide-react";
import Link from "next/link";

export default function NewBookStudio() {
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [isPaid, setIsPaid] = useState(false);
  const [coinPrice, setCoinPrice] = useState(15);
  
  const allTags = ["Dark Romance", "Enemies to Lovers", "Mafia", "Slow Burn", "Morally Grey", "Heist", "Drama"];

  // Toggle do Componente Array de Chips
  const toggleTag = (tag: string) => {
    setSelectedTags(prev => 
      prev.includes(tag) ? prev.filter(t => t !== tag) : [...prev, tag]
    );
  };

  return (
    <div className="p-6 md:p-12 mb-20 max-w-4xl">
      <Link href="/studio" className="flex items-center text-zinc-500 hover:text-white transition-colors mb-8 w-fit group">
        <ChevronLeft size={20} className="group-hover:-translate-x-1 transition-transform" />
        <span className="font-medium text-sm ml-1">Voltar ao Painel</span>
      </Link>

      <h1 className="text-3xl font-bold tracking-tighter text-white mb-8">Rascunho de Capítulo</h1>

      <form className="space-y-12">
        {/* Core Info - Clean Inputs Medium/Notion style */}
        <section className="space-y-6">
          <div>
            <input 
              type="text" 
              placeholder="Título da Obra / Capítulo" 
              className="w-full bg-transparent text-4xl md:text-5xl font-black text-white placeholder:text-[#333] border-b border-[#333] focus:border-ideiasAccent outline-none pb-4 transition-colors tracking-tight"
            />
          </div>
          <div>
            <textarea 
              placeholder="Sinopse curta..." 
              className="w-full bg-transparent text-lg text-zinc-400 placeholder:text-[#333] border-b border-[#333] focus:border-ideiasAccent outline-none pb-4 transition-colors resize-none h-[68px]"
            />
          </div>
        </section>

        {/* Mid Section: Cover & Tags */}
        <section className="grid grid-cols-1 md:grid-cols-2 gap-10">
          <div>
            <h3 className="text-xs font-bold tracking-widest text-zinc-600 mb-4 uppercase">Capa do Livro</h3>
            {/* Drag and Drop visual Area */}
            <div className="w-full aspect-[2/3] max-w-[200px] border-2 border-dashed border-[#333] hover:border-ideiasAccent rounded-2xl flex flex-col items-center justify-center text-zinc-600 hover:text-ideiasAccent hover:bg-ideiasAccent/5 cursor-pointer transition-all group shadow-inner">
              <UploadCloud size={32} className="mb-3 group-hover:scale-110 group-hover:-translate-y-1 transition-transform" />
              <span className="text-xs font-bold font-sans">Arrastar Imagem</span>
            </div>
          </div>

          <div>
             <h3 className="text-xs font-bold tracking-widest text-zinc-600 mb-4 uppercase">Tropes e Emoções</h3>
             <div className="flex flex-wrap gap-2.5">
               {allTags.map(tag => (
                 <button
                   type="button"
                   key={tag}
                   onClick={() => toggleTag(tag)}
                   className={`px-4 py-2 text-xs font-bold rounded-full transition-all border outline-none ${
                     selectedTags.includes(tag) 
                     ? 'bg-ideiasAccent/20 border-ideiasAccent text-white shadow-[0_0_15px_rgba(159,18,57,0.3)]' 
                     : 'bg-transparent border-[#333] text-zinc-500 hover:border-zinc-400 hover:text-zinc-300'
                   }`}
                 >
                   {tag}
                 </button>
               ))}
             </div>
          </div>
        </section>

        {/* Text Area / Editor Minimalista */}
        <section>
          <h3 className="text-xs font-bold tracking-widest text-zinc-600 mb-4 uppercase">Corpo Descritivo</h3>
          <textarea 
            placeholder="Dê vida às suas sombras aqui..." 
            className="w-full min-h-[400px] bg-[#0c0a09] text-base md:text-lg text-zinc-300 placeholder:text-[#222] border border-[#222] focus:border-white/20 rounded-2xl p-6 md:p-8 outline-none transition-colors resize-y font-serif leading-[1.8]"
          />
        </section>

        {/* Monetização Paywall Toggle Builder */}
        <section className="bg-[#111] p-6 rounded-2xl border border-white/5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6 shadow-xl">
          <div>
            <h3 className="text-lg font-bold text-white flex items-center tracking-tight">
              <Coins size={18} className="text-ideiasAccent mr-2" />
              Retenção em Paywall
            </h3>
            <p className="text-xs text-zinc-500 mt-1 max-w-[280px]">Este capítulo será bloqueado automaticamente a partir do 2º parágrafo com piscina de desfoque.</p>
          </div>

          <div className="flex items-center space-x-6">
            {/* CSS-Only Toggle Switch */}
            <label className="relative inline-flex items-center cursor-pointer">
              <input type="checkbox" className="sr-only peer" checked={isPaid} onChange={(e) => setIsPaid(e.target.checked)} />
              <div className="w-12 h-6 bg-[#2a2a2a] rounded-full peer peer-checked:bg-ideiasAccent peer-transition-all after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:after:translate-x-6 hover:after:scale-110"></div>
            </label>

            {/* Input Dinâmico de Coins que desliza conforme Toggle State */}
            {isPaid && (
              <div className="flex items-center space-x-2 animate-in fade-in slide-in-from-right-4">
                <input 
                  type="number" 
                  value={coinPrice} 
                  onChange={(e) => setCoinPrice(Number(e.target.value))}
                  className="w-16 bg-black border border-[#333] rounded-lg px-2 py-1 text-white font-bold text-center focus:border-ideiasAccent outline-none transition-colors"
                />
                <span className="text-sm font-bold text-zinc-500">Moedas</span>
              </div>
            )}
          </div>
        </section>

        {/* Submit */}
        <div className="flex justify-end pt-6 pb-10">
          <button type="button" className="bg-white text-black hover:bg-zinc-200 transition-all font-extrabold rounded-xl px-8 py-3.5 flex items-center shadow-[0_0_20px_rgba(255,255,255,0.15)] hover:shadow-[0_0_25px_rgba(255,255,255,0.25)] hover:scale-105 active:scale-95 duration-200">
            <CheckCircle size={18} className="mr-2" />
            Publicar Tensão
          </button>
        </div>
      </form>
    </div>
  );
}
