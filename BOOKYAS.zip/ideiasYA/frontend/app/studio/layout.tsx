import React from "react";
import Sidebar from "@/components/Sidebar";

export const metadata = {
  title: "IdeiasYA | Estúdio do Autor",
  description: "Crie atmosferas impiedosas.",
};

export default function StudioLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <div className="flex min-h-screen bg-[#060606]">
      {/* O Sidebar ficará fixo do lado esquerdo preenchendo as colunas */}
      <Sidebar />
      <main className="flex-1 ml-16 md:ml-64 relative pb-20 md:pb-0 min-h-screen overflow-x-hidden">
        <div className="max-w-[1600px] mx-auto w-full">
            {children}
        </div>
      </main>
    </div>
  );
}
