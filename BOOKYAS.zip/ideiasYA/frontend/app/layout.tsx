import "./globals.css";
import React from "react";
import Navbar from "@/components/Navbar";
import { CoinStoreProvider } from "@/context/CoinStoreContext";

export const metadata = {
  title: "IdeiasYA | Leituras em Alta Tensão",
  description: "Plataforma premium para amantes de histórias viscerais.",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="pt-BR">
      <body>
        <CoinStoreProvider>
          <Navbar />
          {children}
        </CoinStoreProvider>
      </body>
    </html>
  );
}
