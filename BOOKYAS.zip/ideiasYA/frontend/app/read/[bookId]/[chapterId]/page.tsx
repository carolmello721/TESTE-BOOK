"use client";

import { useState, useEffect } from "react";
import { Lock, ChevronLeft } from "lucide-react";
import Link from "next/link";
import { useCoinStore } from "@/context/CoinStoreContext";

export default function ReadingPage({ params }: { params: { bookId: string, chapterId: string } }) {
  const { openStore } = useCoinStore();
  const [fontSize, setFontSize] = useState<number>(1);
  const [scrollProgress, setScrollProgress] = useState(0);
  const isUnlocked = false; // Mocking Locked content paywall
  const fontSizes = ["text-base", "text-lg", "text-xl", "text-2xl", "text-3xl"];

  const chapterTitle = "Capítulo 1: O Inimigo Desconhecido";

  const paragraphs = [
    "Katarina sentiu a lâmina fria pressionada contra a lateral de seu pescoço. O cheiro de sândalo e fumaça inundou seus sentidos, uma fragrância que ela dolorosamente aprendeu a associar ao seu maior erro de cálculo.",
    "Matteo sequer precisou agarrá-la. Apenas a presença dele ali, materializando-se das sombras macabras da biblioteca antiga, foi o suficiente para paralisar todos os músculos de seu corpo. 'Você realmente achou que conseguiria sair de Veneza antes do amanhecer, Kat?' a voz rouca dele sussurrou, deslizando quase como uma carícia letal contra a orelha dela.",
    "Mover um único centímetro poderia ser fatal. Não apenas por causa do aço afiado da adaga veneziana roçando em sua pele, mas porque seus próprios batimentos cardíacos estavam martelando tão dolorosamente rápido em seu peito que ela temia desabar se seus olhos finalmente o encarassem.",
    "Ele a virou devagar contra a parede. Os dedos ásperos do mafioso tocaram a seda escura do vestido dela com uma reverência que margeava a insanidade. 'Eu te pus o mundo de joelhos.' Matteo abaixou a lâmina milimetricamente até pousar a ponta afiada abaixo do maxilar dela, erguendo o rosto de Katarina. Os olhos dele eram duas pedras de ônix cravadas e impiedosas.",
    "Katarina tentou encontrar a própria voz, mascarando o pavor com deboche flamejante. 'Você chama isso de amor? Confinamento? Uma gaiola de ouro pintada com sangue fresco das minhas amizades?' Um leve sorriso cruel despontou no rosto do herdeiro rival, revelando os traços de um homem que adorava ser odiado mais do que ser adorado..."
  ];

  // Listener nativo ultra-focado de Scroll para o Loading Progress Horizontal Inferior
  useEffect(() => {
    const updateProgress = () => {
      const scrollY = window.scrollY;
      const docHeight = document.documentElement.scrollHeight - window.innerHeight;
      
      if (docHeight > 0) {
        setScrollProgress((scrollY / docHeight) * 100);
      } else {
        setScrollProgress(100); // Se tela não tiver scroll, preencha automaticamente.
      }
    };
    
    // Dispara a montagem para carregar a barra e monitora o evento de rolagem das rodas
    updateProgress();
    window.addEventListener("scroll", updateProgress);
    return () => window.removeEventListener("scroll", updateProgress);
  }, []);

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-ideiasText font-serif selection:bg-ideiasAccent selection:text-white">
      
      {/* Header Fixo / Zen Mode Topbar */}
      <header className="sticky top-0 z-50 w-full bg-[#0a0a0a]/80 backdrop-blur-md border-b border-white/5 transition-all">
        <div className="max-w-3xl mx-auto px-4 h-14 flex items-center justify-between">
          <Link href="/" className="flex items-center text-ideiasMuted hover:text-white transition-colors">
            <ChevronLeft size={24} />
            <span className="ml-1 text-sm font-sans font-medium hidden sm:block">Prateleira</span>
          </Link>
          
          <div className="text-sm font-sans text-ideiasMuted truncate max-w-[50%] font-semibold">
            {chapterTitle}
          </div>

          <div className="flex items-center space-x-2 font-sans">
            <span className="text-xs text-ideiasMuted mr-2 hidden sm:block">Ajustar Tensão Visual</span>
            <button 
              onClick={() => setFontSize(Math.max(0, fontSize - 1))}
              disabled={fontSize === 0}
              className="w-8 h-8 rounded-full bg-white/5 flex items-center justify-center hover:bg-white/10 disabled:opacity-30 transition-colors"
              title="Reduzir Fonte"
            >
              A-
            </button>
            <button 
              onClick={() => setFontSize(Math.min(fontSizes.length - 1, fontSize + 1))}
              disabled={fontSize === fontSizes.length - 1}
              className="w-8 h-8 rounded-full bg-white/5 flex items-center justify-center hover:bg-white/10 disabled:opacity-30 transition-colors font-bold"
              title="Aumentar Fonte"
            >
              A+
            </button>
          </div>
        </div>
      </header>

      {/* ÁREA DE LEITURA (Typográfico e Responsivo) */}
      <main className="relative max-w-2xl mx-auto px-6 pt-12 pb-32">
        <h1 className="text-3xl md:text-4xl font-bold mb-10 text-white font-sans tracking-tight leading-tight">
          {chapterTitle}
        </h1>

        {/* Artigo Dinâmico baseando-se no Estado do FontSize Array */}
        <article className={`space-y-8 ${fontSizes[fontSize]} leading-[1.8] text-[#d4d4d4] tracking-wide relative`}>
          {paragraphs.map((textoParagrafo, idx) => {
            // Lógica Hard-Coded de Paywall: Borra os parágrafos se Passar do Idx 1 (0 ou 1 aparecem limpos)
            const isBlurred = !isUnlocked && idx > 1;
            const blurClass = isBlurred ? "blur-[6px] opacity-20 select-none pointer-events-none" : "opacity-90";

            return (
              <p key={idx} className={`transition-all duration-700 ease-in-out ${blurClass}`}>
                {textoParagrafo}
              </p>
            );
          })}

          {/* Overlay de Bloqueio (O Paywall Cadeado Absolute por Cima da Névoa de Blur) */}
          {!isUnlocked && (
            <div className="absolute bottom-0 left-0 w-full h-[65%] bg-gradient-to-t from-[#0a0a0a] via-[#0a0a0a]/90 to-transparent flex flex-col items-center justify-end pb-8">
              <div className="p-8 backdrop-blur-2xl bg-white/5 border border-white/10 rounded-3xl flex flex-col items-center text-center shadow-2xl max-w-sm w-full mx-auto transform translate-y-6">
                
                {/* Glow Ring do Cadeado */}
                <div className="w-16 h-16 bg-ideiasAccent/10 text-ideiasAccent rounded-full flex items-center justify-center mb-6 ring-2 ring-ideiasAccent/40 shadow-inner">
                  <Lock size={28} />
                </div>
                
                <h3 className="font-sans text-2xl font-black text-white mb-3">Tensão Reservada</h3>
                <p className="font-sans text-sm text-zinc-400 mb-8 leading-relaxed">
                  O ar de Matteo gela a espinha. Para descobrir a lâmina seguinte desse romance de risco, resgate o resto desse capítulo.
                </p>
                
                <button 
                  onClick={openStore}
                  className="w-full bg-ideiasAccent hover:bg-[#881335] text-white font-sans font-bold py-3.5 px-4 rounded-xl shadow-[0_0_20px_rgba(159,18,57,0.3)] hover:shadow-[0_0_25px_rgba(159,18,57,0.6)] transition-all flex items-center justify-between group"
                >
                  <span className="pl-2">Desbloquear Agora</span>
                  <span className="bg-black/30 px-3 py-1 rounded text-white font-bold group-hover:scale-105 transition-transform">
                    15 Moedas
                  </span>
                </button>
              </div>
            </div>
          )}
        </article>
      </main>

      {/* StatusBar Inferior da Rolagem de Progressão (%) */}
      <div className="fixed bottom-0 left-0 w-full h-[6px] bg-[#222] z-50">
        <div 
          className="h-full bg-ideiasAccent shadow-[0_0_8px_rgba(159,18,57,0.8)]"
          style={{ width: `${scrollProgress}%`, transition: 'width 0.1s ease-out' }}
        />
      </div>
      
    </div>
  );
}
