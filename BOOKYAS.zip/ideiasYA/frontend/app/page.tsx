import BookCard from "@/components/BookCard";

export default function Home() {
  // Mock FICTÍCIO com os dados requeridos de "Código de Tensão" injetados
  const mockBooks = [
    {
      id: "1",
      title: "Código de Tensão",
      author: "Katarina Writer",
      coverUrl: "https://images.unsplash.com/photo-1614583224978-f05ce51ef5fa?q=80&w=600&auto=format&fit=crop", 
      tensionLevel: 10,
      tropes: ["Dark Romance", "Enemies to Lovers", "Morally Grey"],
    },
    {
      id: "2",
      title: "Sombras de Matteo",
      author: "Julio C.",
      coverUrl: "https://images.unsplash.com/photo-1541963463532-d68292c34b19?q=80&w=600&auto=format&fit=crop", 
      tensionLevel: 8,
      tropes: ["Mafia", "Slow Burn", "Obsession"],
    },
    {
      id: "3",
      title: "A Última Jogada",
      author: "Katarina Writer",
      coverUrl: "https://images.unsplash.com/photo-1589998059171-988d887df646?q=80&w=600&auto=format&fit=crop", 
      tensionLevel: 9,
      tropes: ["Rivals to Lovers", "Heist"],
    },
    {
      id: "4",
      title: "Juramento Quebrado",
      author: "Author Anônimo",
      coverUrl: "", 
      tensionLevel: 5,
      tropes: ["Drama", "Arranged Marriage"],
    }
  ];

  return (
    <main className="min-h-screen bg-ideiasBg pb-20">
      
      {/* Hero Section Minimalista */}
      <section className="pt-16 pb-12 px-4 max-w-7xl mx-auto flex flex-col items-start">
        <h1 className="text-4xl md:text-6xl font-black tracking-tight text-ideiasText mb-4">
          Descubra sua <span className="text-ideiasAccent drop-shadow-md">próxima obsessão.</span>
        </h1>
        <p className="text-lg text-ideiasMuted max-w-2xl">
          Navegue pelas prateleiras organizadas pelo nosso termômetro de tensão e encontre o plot perfeito para o seu batimento cardíaco.
        </p>
      </section>

      {/* Prateleira 1: Em Alta Tensão (Scroll Horizontal Snapshot) */}
      <section className="mt-8 relative">
        <div className="px-4 max-w-7xl mx-auto mb-4 flex items-baseline space-x-3">
          <h2 className="text-2xl font-bold text-ideiasText">Em Alta Tensão 🔥</h2>
          <span className="text-sm text-ideiasMuted">Recomendados para hoje</span>
        </div>
        
        {/* Container Horizontal Nativo */}
        <div className="w-full overflow-x-auto hide-scrollbar snap-x snap-mandatory px-4 pb-10 pt-2">
          <div className="flex space-x-6 w-max mx-auto md:mx-0 pr-8">
            {mockBooks.map((book) => (
              <BookCard
                key={book.id}
                title={book.title}
                author={book.author}
                coverUrl={book.coverUrl}
                tensionLevel={book.tensionLevel}
                tropes={book.tropes}
              />
            ))}
          </div>
        </div>
      </section>

      {/* Prateleira 2: Categorizados */}
      <section className="mt-4 relative">
        <div className="px-4 max-w-7xl mx-auto mb-4 flex items-baseline space-x-3">
          <h2 className="text-2xl font-bold text-ideiasText">Dark Romance Especiais</h2>
          <span className="text-sm text-ideiasMuted">Explorando o abismo</span>
        </div>
        
        <div className="w-full overflow-x-auto hide-scrollbar snap-x snap-mandatory px-4 pb-10 pt-2">
          <div className="flex space-x-6 w-max pr-8">
             {/* Renderização Reversa para popular a prateleira com as mesmas Mocks mas ordem diferente */}
            {[...mockBooks].reverse().map((book) => (
              <BookCard
                key={book.id + "rev"}
                title={book.title}
                author={book.author}
                coverUrl={book.coverUrl}
                tensionLevel={book.tensionLevel}
                tropes={book.tropes}
              />
            ))}
          </div>
        </div>
      </section>

    </main>
  );
}
