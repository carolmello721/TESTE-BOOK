"use client";

import React, { createContext, useContext, useState } from "react";
import CoinStoreModal from "@/components/CoinStoreModal";

type CoinStoreContextType = {
  openStore: () => void;
  closeStore: () => void;
};

const CoinStoreContext = createContext<CoinStoreContextType | undefined>(undefined);

export function CoinStoreProvider({ children }: { children: React.ReactNode }) {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <CoinStoreContext.Provider value={{ openStore: () => setIsOpen(true), closeStore: () => setIsOpen(false) }}>
      {children}
      
      {/* Quando a Loja "Despertar Globalmente", preencherá a tela com Z-Index maximo sem quebrar a raiz! */}
      {isOpen && <CoinStoreModal onClose={() => setIsOpen(false)} />}
    </CoinStoreContext.Provider>
  );
}

export function useCoinStore() {
  const context = useContext(CoinStoreContext);
  if (!context) throw new Error("useCoinStore precisa englobar a arvore de leitura em layout.tsx");
  return context;
}
