import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        ideiasBg: "#0c0a09", // Neutral graphite para o Dark mode global
        ideiasSurface: "#1c1917", // Elevated graphite para os cards
        ideiasAccent: "#9f1239", // Bordô Vibrante (Rose/Claret 800)
        ideiasText: "#fafaf9", // Soft white Text
        ideiasMuted: "#a8a29e", // Subtitulos cinza
      },
    },
  },
  plugins: [],
};
export default config;
